package br.com.netshoes.domain;



public class TimecoracaoId {

	private final Long id;
	
	public TimecoracaoId(Long id) {
		this.id = id;
	}
	
	public Long getId() {
		return id;
	}
	
}
