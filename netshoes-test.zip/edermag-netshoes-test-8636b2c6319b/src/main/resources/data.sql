INSERT INTO Campanha (id, timecoracao, campanha, nomecompleto, email, datanascimento)
VALUES(1, 'Palmeiras', '01/01/17 a 01/01/18', 'Paulo Silva', 'paulo@hotmail.com', '25/09/12');
